package com.exam.dao;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.exam.dto.MemberDTO;

// 실질적인 구현 객체이다 표시해야 함
@Repository		// @Service 아래에 있는 annotation : DAO를 스프링 컨테이너에게 인식시켜주는 역할
public class MemberDAOImple implements MemberDAO {
	
	private static final String NAMESPACE = "com.exam.MemberMapper";
	
	//최종 세션 주입
	@Inject		//@Autowired도 가능하지만 @Inject가 조금 더 정확함
	private SqlSession sqlSession;
	
	
	@Override
	public String getTIme() {
		//return sqlSession.selectOne("getTime");	// id로 매칭(memberMapper.xml에 있는)
		return sqlSession.selectOne(NAMESPACE+".getTime");
	}

	@Override
	public void insertMember(MemberDTO mdto) {
		sqlSession.insert(NAMESPACE+".insertMember", mdto);
	}

}
