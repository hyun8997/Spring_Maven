package com.exam.dao;

import java.util.List;

import com.exam.dto.BbsDTO;

public interface BbsDAO {
	public void insert(BbsDTO bdto) throws Exception;
	public BbsDTO read(Integer bid) throws Exception;
	public void update(BbsDTO bdto) throws Exception;
	public void delete(Integer bid) throws Exception;
	public List<BbsDTO> list() throws Exception;
}
