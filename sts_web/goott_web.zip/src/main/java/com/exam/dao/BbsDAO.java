package com.exam.dao;

import java.util.List;

import com.exam.dto.BbsDTO;
import com.exam.dto.PageCriteria;

public interface BbsDAO {
	public void insert(BbsDTO bdto) throws Exception;
	public BbsDTO read(Integer bid) throws Exception;
	public void update(BbsDTO bdto) throws Exception;
	public void delete(Integer bid) throws Exception;
	public List<BbsDTO> list() throws Exception;
	//페이징 처리
	public List<BbsDTO> listPage(int page) throws Exception;
	
	public List<BbsDTO> listCriteria(PageCriteria  pageCriteria) throws Exception;
	
	//전체 데이터 조회
	public int countData(PageCriteria pageCria) throws Exception;
}
