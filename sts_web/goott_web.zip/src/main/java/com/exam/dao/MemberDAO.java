package com.exam.dao;

import com.exam.dto.MemberDTO;

public interface MemberDAO {
	public String getTIme();										//시간구하기
	public void insertMember(MemberDTO mdto);	//최초 맴버 등록
}
