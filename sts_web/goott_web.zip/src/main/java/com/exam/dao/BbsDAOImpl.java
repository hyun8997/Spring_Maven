package com.exam.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.exam.dto.BbsDTO;
import com.exam.dto.PageCriteria;

// dao역할, repository가 된다.	  dto는 개발자가 개발하려고 만든 폼이고 doa는 db에서 받아놓은 데이터를 저장
@Repository
public class BbsDAOImpl implements BbsDAO {
	
	@Inject
	private SqlSession sqlSession;
	
	
	@Override
	public void insert(BbsDTO bdto) throws Exception {
		sqlSession.insert("insert", bdto);
	}

	@Override
	public BbsDTO read(Integer bid) throws Exception {
		return sqlSession.selectOne("read",bid);
	}

	@Override
	public void update(BbsDTO bdto) throws Exception {
		sqlSession.update("update", bdto);
	}

	@Override
	public void delete(Integer bid) throws Exception {
		sqlSession.delete("delete", bid);
	}

	@Override
	public List<BbsDTO> list() throws Exception {
		return sqlSession.selectList("list");
	}

	// 페이징 처리
	@Override
	public List<BbsDTO> listPage(int page) throws Exception {
		//페이지에 해당하는 리스트 보여주도록
		if(page <= 0) {
			page = 1;
		}
		
		page = (page-1)*10;	//10개 단위로 끊기, 2페이지는 10번부터 시작함
		
		return sqlSession.selectList("listPage", page);
	}

	// 페이징 처리2
	@Override
	public List<BbsDTO> listCriteria(PageCriteria pageCriteria) throws Exception {
		
		return sqlSession.selectList("listCriteria", pageCriteria);		
		//PageCriteria 객체를 넣어주면 프레임워크에 의해 매퍼에서 알아서 게터를 인식해서 매칭해줌
	}

	@Override
	public int countData(PageCriteria pageCria) throws Exception {
		// TODO Auto-generated method stub
		return sqlSession.selectOne("countData", pageCria);
	}

}
