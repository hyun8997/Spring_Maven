package com.exam.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.exam.dto.BbsDTO;

// dao역할, repository가 된다.	  dto는 개발자가 개발하려고 만든 폼이고 doa는 db에서 받아놓은 데이터를 저장
@Repository
public class BbsDAOImpl implements BbsDAO {
	
	@Inject
	private SqlSession sqlSession;
	
	
	@Override
	public void insert(BbsDTO bdto) throws Exception {
		sqlSession.insert("insert", bdto);
	}

	@Override
	public BbsDTO read(Integer bid) throws Exception {
		return sqlSession.selectOne("read",bid);
	}

	@Override
	public void update(BbsDTO bdto) throws Exception {
		sqlSession.update("update", bdto);
	}

	@Override
	public void delete(Integer bid) throws Exception {
		sqlSession.delete("delete", bid);
	}

	@Override
	public List<BbsDTO> list() throws Exception {
		return sqlSession.selectList("list");
	}

}
