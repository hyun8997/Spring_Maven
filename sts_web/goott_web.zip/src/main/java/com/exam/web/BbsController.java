package com.exam.web;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.exam.dto.BbsDTO;
import com.exam.service.BbsService;

// 어노테이션써서 각각의 기능들을 만들고 주소를 부여해서 컨트롤러에서 호출
// 하나의 컨트롤러에서 여러개의 주소 부여
@Controller
//    로컬호스트/  <= 이 주소(root)를 홈이 쓰고있음
//    그러므로 root를 쓰지 않고 한단계 더 내려가기로 함, 선언
@RequestMapping("/bbs/")
public class BbsController {
	// 로거 사용
	private static final Logger LOGGER = LoggerFactory.getLogger(BbsController.class);
	
	@Inject		//서비스 호출
	private BbsService bsvc;		// controller와 DAO 사이 연결 계층(service)
	
	@RequestMapping(value = "/write", method = RequestMethod.GET)	
										// root/bbs/write 경로에 GET 방식으로 들어왔을때 밑의 함수 실행
	public void writeGET(BbsDTO bdto, Model model) throws Exception{
		LOGGER.info("...write GET...");		// 로그에 표시
	}
	
	@RequestMapping(value = "/write", method = RequestMethod.POST)
	public String writePost(BbsDTO bdto, Model model) throws Exception{
		LOGGER.info("---- write POST ----");
		LOGGER.info(bdto.toString());
		
		//bsvc.write(bdto);		//db등록
		
		model.addAttribute("result", "success");		// 페이지 이동 확인, 결과 잘 넘어가는지 확인
		
		return "/bbs/list";
	}
	
	
}
