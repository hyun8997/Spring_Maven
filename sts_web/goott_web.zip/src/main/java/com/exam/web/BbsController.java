package com.exam.web;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.exam.dto.BbsDTO;
import com.exam.dto.PageCriteria;
import com.exam.dto.PagingMaker;
import com.exam.service.BbsService;

@Controller
@RequestMapping("/bbs/*")
public class BbsController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BbsController.class);
	
	@Inject
	private BbsService bsvc;     // controller와 DAO 사이 연결 계층
	
	@RequestMapping(value = "/write", method = RequestMethod.GET)
	public void writeGET(BbsDTO bdto, Model model) throws Exception{
		LOGGER.info("..... write GET ....");
	}
	
	@RequestMapping(value = "/write", method = RequestMethod.POST)
	public String writePost(BbsDTO bdto, RedirectAttributes reAttr) throws Exception {
		LOGGER.info("---- write POST ----");
		LOGGER.info(bdto.toString());
		
		bsvc.write(bdto);		
		
		//model.addAttribute("result", "success");
		reAttr.addFlashAttribute("result", "success"); 
		// addFlashAttribute() : 한번만 전송하도록 전달하는 메소드  => RedirectAttributes 에서 생성
		
		//return "/bbs/list";
		return "redirect:/bbs/list";				
	}
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public void list(Model model) throws Exception {
		LOGGER.info(".... list 출력 ....");
		
		model.addAttribute("list", bsvc.list());
	}
	
	
	// 파라미터를 받는 방법 여러가지, 지금 받는건 bid 숫자임
	// @RequestParam - Servelet에서 request.getParameter()와 유사한 기능
	// => 넘어온 정보는 문자, db로 보낼 요청은 숫자 => 문자열, 숫자, 날짜 등의 형변환이 쉽게 되는 장점
//	@RequestMapping(value = "/read", method = RequestMethod.GET)
//	public void read(@RequestParam("bid") int bid, Model model) throws Exception{
//		
//		model.addAttribute(bsvc.read(bid));
//		
//		// addAttribute에서 key(name)을 사용하지 않을 경우 key는 클래스명을 자동으로 소문자로 인식해서 저장해 줌!
//	}
	
	//삭제 처리
	//data 감추려고 포스트했음
//	@RequestMapping(value = "/delete", method = RequestMethod.POST)
//	public String delete(@RequestParam("bid") int bid, RedirectAttributes reAttr) throws Exception {
//		//RedirectAttributes는 딜레이타임을 벌어줌
//		bsvc.remove(bid);
//		
//		reAttr.addFlashAttribute("result", "success");
//		return "redirect:/bbs/list";
//	}
	
	//수정 페이지 뷰
//	@RequestMapping(value = "/modify", method = RequestMethod.GET)
//	public void modifyGET(@RequestParam("bid") int bid, Model model) throws Exception{		//get으로 보내면 이름이 같으니까 알아서 들어온다?
//		model.addAttribute(bsvc.read(bid));
//	}
	
	//수정 처리
//	@RequestMapping(value = "/modify", method = RequestMethod.POST)
//	public String modifyPOST(BbsDTO bdto, RedirectAttributes reAttr) throws Exception{	//알아서 매퍼에서 DTO로 받아오게 되있음
//		LOGGER.info("---- 수정 처리 -----");
//		
//		bsvc.modify(bdto);
//		
//		reAttr.addFlashAttribute("result", "success");
//		
//		return "redirect:/bbs/list";
//	}
	
	// 페이징 처리, 아직 베타임
//	@RequestMapping(value = "/pageListTest", method = RequestMethod.GET)
//	public void pageListTest(PageCriteria pCria, Model model) throws Exception{
//		LOGGER.info("---- pageList beta 출력 ----");
//		
//		//pCria.setNumPerPage(5);
//		
//		model.addAttribute("list", bsvc.listCriteria(pCria));
//	}
	
	// 페이징 + 버튼 처리
	@RequestMapping(value = "/pageList", method = RequestMethod.GET)
	public void pageList(PageCriteria pCria, Model model) throws Exception{
		LOGGER.info(pCria.toString());
		
		model.addAttribute("list", bsvc.listCriteria(pCria));
		
		PagingMaker pagingMaker = new PagingMaker();
		
		pagingMaker.setCri(pCria);
		//pagingMaker.setTotalData(155);			//그냥 숫자 넣어서 일단 동작 테스트
		pagingMaker.setTotalData(bsvc.listCountData(pCria));
		
		model.addAttribute("pagingMaker", pagingMaker);
	}
	
	// MakeURI 적용 후 readPage
	@RequestMapping(value = "/readPage", method = RequestMethod.GET)
	public void read(@RequestParam("bid") int bid, 
			@ModelAttribute("pCri") PageCriteria pCri,
			Model model) throws Exception{
		
		model.addAttribute(bsvc.read(bid));
	}
	
	// MakeURI 적용 후 delPage, 뷰 없고 동작만
	@RequestMapping(value = "/delPage", method = RequestMethod.GET)
	public String delPage(@RequestParam("bid") int bid, PageCriteria pCri, RedirectAttributes reAttr) throws Exception{
		
		bsvc.remove(bid);
		
		reAttr.addAttribute("page",pCri.getPage());							//정보가 남아있어야 하니까 flash뺌
		reAttr.addAttribute("numPerPage",pCri.getNumPerPage());
		reAttr.addFlashAttribute("result", "success");
		
		return "redirect:/bbs/pageList";
	}
	
	// MakeURI 적용 후 modifyPage
	@RequestMapping(value = "/modifyPage", method = RequestMethod.GET)
	public void modifyGET(@RequestParam("bid") int bid, @ModelAttribute("pCri") PageCriteria pCri, Model model) throws Exception{
		model.addAttribute(bsvc.read(bid));
	}
	
	// MakeURI 적용 후 modifyPage
	@RequestMapping(value = "/modifyPage", method = RequestMethod.POST)
	public String modifyPOST(BbsDTO bdto, PageCriteria pCri, RedirectAttributes reAttr) throws Exception{
		
		bsvc.modify(bdto);
		
		reAttr.addAttribute("page", pCri.getPage());
		reAttr.addAttribute("numPerPage", pCri.getNumPerPage());
		reAttr.addFlashAttribute("result", "success");
		
		return "redirect:/bbs/pageList";
	}
	
	
	
	
	
	
}
