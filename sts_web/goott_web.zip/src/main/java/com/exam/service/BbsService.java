package com.exam.service;

import java.util.List;

import com.exam.dto.BbsDTO;

public interface BbsService {
	public void write(BbsDTO bdto) throws Exception;
	public BbsDTO read(Integer bid) throws Exception;
	public void modify(BbsDTO bdto) throws Exception;
	public void remove(Integer bid) throws Exception;
	public List<BbsDTO> list() throws Exception;
	
}
