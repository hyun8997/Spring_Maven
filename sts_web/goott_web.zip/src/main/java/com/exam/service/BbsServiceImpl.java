package com.exam.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.exam.dao.BbsDAO;
import com.exam.dto.BbsDTO;
import com.exam.dto.PageCriteria;

@Service
public class BbsServiceImpl implements BbsService {
	
	@Inject
	private BbsDAO bdao;
	
	
	@Override
	public void write(BbsDTO bdto) throws Exception {
		// TODO Auto-generated method stub
		bdao.insert(bdto);
	}

	@Override
	public BbsDTO read(Integer bid) throws Exception {
		// TODO Auto-generated method stub
		return bdao.read(bid);
	}

	@Override
	public void modify(BbsDTO bdto) throws Exception {
		// TODO Auto-generated method stub
		bdao.update(bdto);
	}

	@Override
	public void remove(Integer bid) throws Exception {
		// TODO Auto-generated method stub
		bdao.delete(bid);
	}

	@Override
	public List<BbsDTO> list() throws Exception {
		// TODO Auto-generated method stub
		return bdao.list();
	}

	@Override
	public List<BbsDTO> listCriteria(PageCriteria pCria) throws Exception {
		// TODO Auto-generated method stub
		return bdao.listCriteria(pCria);
	}

	@Override
	public int listCountData(PageCriteria pCria) throws Exception {
		// TODO Auto-generated method stub
		return bdao.countData(pCria);
	}

}
