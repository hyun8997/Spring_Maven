package com.exam.dto;

public class FindCriteria {
	private String findType;	// 검색 조건
	private String keyword;	// 검색 keyword
	
	public String getFindType() {
		return findType;
	}
	public void setFindType(String findType) {
		this.findType = findType;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	
	@Override
	public String toString() {
		return "[FindCriteriaa - findType:"+this.findType+", keyword:"+this.keyword+"]";
	}
	
	
}
