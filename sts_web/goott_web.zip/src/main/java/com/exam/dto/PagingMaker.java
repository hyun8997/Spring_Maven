package com.exam.dto;

import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

public class PagingMaker {
	private int totalData;	//전체 데이터 갯수
	private int startPage;	//페이지 목록의 시작번호
	private int endPage;	//페이지 목록의 끝 번호
	private boolean prev;		//이전 버튼을 나타내는 논리값
	private boolean next;		//다음 버튼을 나타내는 논리값
	
	private int displayPageNum = 10;		//페이지 목록에 나타낼 페이지 번호의 수
	
	private PageCriteria cri;

	public int getTotalData() {
		return totalData;
	}

	public void setTotalData(int totalData) {
		this.totalData = totalData;
		
		getPagingData();
		//전체 데이터 갯수를 넣으면서 시작 페이지 및 끝 페이지 등 정리
	}
	
	
	private void getPagingData() {
		// (현재 페이지 번호 / 페이지 목록에 나타낼 페이지 번호의 수)*페이지 목록에 나타낼 페이지 번호의 수
		endPage = (int) (Math.ceil(cri.getPage()/(double)displayPageNum)*displayPageNum);		
																		//정확도 보장을 위해 실수로 나누고 정수 곱함
		/*
		 * 	int i = 3/100   => 원래 0.03 -> int로 0
		 * 
		 * 3/100  * 100 = int로 0
		 * 
		 * 3/100.0 *100 = 3   ==> 정확도 개선
		 */
		
		startPage = (endPage - displayPageNum) + 1;
		
		int finalEndPage = (int)(Math.ceil(totalData/(double)cri.getNumPerPage()));
		
		if(endPage > finalEndPage) {
			endPage = finalEndPage;	//마지막 페이지가 최종보다 크면 안되니까 최종으로 지정해버림
		}
		
		//시작 페이지가 1보다 크면 왼쪽에 화살표가 뜨게, 마지막이 최종보다 작을떄 오른쪽에 화살표
		prev = startPage == 1? false:true;
		next = endPage*cri.getNumPerPage() >= totalData? false:true;
	}// getPaginfData() end
	
	
	//UriComponentBuilder를 통한 페이징 처리
	public String makeURI(int page) {
		UriComponents uriComponents = UriComponentsBuilder.newInstance()
				.queryParam("page", page)
				.queryParam("numPerPage", cri.getNumPerPage())
				.build();
		
		return uriComponents.toUriString();		
	}
	
	
	

	public int getStartPage() {
		return startPage;
	}

	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}

	public int getEndPage() {
		return endPage;
	}

	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}

	public boolean isPrev() {
		return prev;
	}

	public void setPrev(boolean prev) {
		this.prev = prev;
	}

	public boolean isNext() {
		return next;
	}

	public void setNext(boolean next) {
		this.next = next;
	}

	public int getDisplayPageNum() {
		return displayPageNum;
	}

	public void setDisplayPageNum(int displayPageNum) {
		this.displayPageNum = displayPageNum;
	}

	public PageCriteria getCri() {
		return cri;
	}

	public void setCri(PageCriteria cri) {
		this.cri = cri;
	}
	
	
	
}
