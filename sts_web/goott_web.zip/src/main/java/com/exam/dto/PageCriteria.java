package com.exam.dto;

public class PageCriteria {
	private int page;					// 현재 페이지
	private int numPerPage;		// 페이지 당 갯수
	
	public PageCriteria() {
		this.page=1;				//기본 1페이지
		this.numPerPage=10;	//기본 페이지당 10개
	}

	public int getPage() {
		return this.page;
	}
	
	public int getNumPerPage() {
		return this.numPerPage;
	}
	
	public void setPage(int page) {
		if(page<=0) {
			this.page = 1;	//앞 3개 뒤3개 하면 음수가 나올 수 있으니까 미리 처리
			return;				//더 진행 안되게 끊기
		}
		
		this.page=page;	//끊고 무조건 넘어온 페이지로 가도록
	}
	
	public void setNumPerPage(int numPerPage) {		//0개로 의미없는수나 1000개 같이 너무 큰 수 자르기
		if(numPerPage<=0 || numPerPage>50) {
			this.numPerPage = 10;
			return;
		}
		
		this.numPerPage = numPerPage;
	}
	
	// 시작 페이지 설정 - 시작 번호 알아내기
	public int getStartPage() {
		return (this.page-1)*numPerPage;
	}
	
	@Override
	public String toString() {
		return "PageCriteria Info [page:"+this.page
				+", numPerPage:"+this.numPerPage
				+"]";
	}
	
	
}	


