package com.exam.web;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.exam.dao.BbsDAO;
import com.exam.dto.BbsDTO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/root-context.xml"})
public class BbsDAOTest {
	
	@Inject
	private BbsDAO bdao;
	
	private static Logger logger = LoggerFactory.getLogger(BbsDAOTest.class);
	
	//@Test
	public void insertTest() throws Exception {
		BbsDTO bdto = new BbsDTO();
		bdto.setSubject("테스트_제목3");
		bdto.setWriter("테스트_작성자3");
		bdto.setContent("테스트_내용3");
		bdao.insert(bdto);
	}
	
	//@Test
	public void readTest() throws Exception{
		logger.info(bdao.read(1).toString());
	}
	
	//@Test
	public void udateTest() throws Exception{
		BbsDTO bdto = new BbsDTO();
		bdto.setBid(3);
		bdto.setSubject("테스트_수정된제목");
		bdto.setContent("테스트_수정된내용");
		bdao.update(bdto);
	}
	
	//@Test
	public void deleteTest() throws Exception{
		bdao.delete(3);
	}
	
	@Test
	public void listTest() throws Exception{
		logger.info(bdao.list().toString());
	}
	
	
	
}
