package com.exam.web;

import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.exam.dao.BbsDAO;
import com.exam.dto.BbsDTO;
import com.exam.dto.PageCriteria;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/root-context.xml"})
public class BbsDAOTest {
	
	@Inject
	private BbsDAO bdao;
	
	private static Logger logger = LoggerFactory.getLogger(BbsDAOTest.class);
	
	//@Test
	public void insertTest() throws Exception {
		BbsDTO bdto = new BbsDTO();
		bdto.setSubject("테스트_제목3");
		bdto.setWriter("테스트_작성자3");
		bdto.setContent("테스트_내용3");
		bdao.insert(bdto);
	}
	
	//@Test
	public void readTest() throws Exception{
		logger.info(bdao.read(1).toString());
	}
	
	//@Test
	public void udateTest() throws Exception{
		BbsDTO bdto = new BbsDTO();
		bdto.setBid(3);
		bdto.setSubject("테스트_수정된제목");
		bdto.setContent("테스트_수정된내용");
		bdao.update(bdto);
	}
	
	//@Test
	public void deleteTest() throws Exception{
		bdao.delete(3);
	}
	
	//@Test
	public void listTest() throws Exception{
		logger.info(bdao.list().toString());
	}
	
	//페이징 테스트
	//@Test
	public void pagingTest() throws Exception{
		int page=3;
		
		List<BbsDTO> list = bdao.listPage(page);
		
		for(BbsDTO bdto : list) {
			logger.info(bdto.getBid()+" : "+bdto.getSubject());
		}
	}
	
	// PageCriteria를 통한 페이징 설정 test
	//@Test
	public void criteriaTest() throws Exception{
		PageCriteria pCria  = new PageCriteria();
		pCria.setPage(3);
		pCria.setNumPerPage(25);
		
		List<BbsDTO> list = bdao.listCriteria(pCria);
		
		for(BbsDTO bdto : list) {
			logger.info(bdto.getBid()+" : "+bdto.getSubject());
		}
		
	}
	
	@Test
	public void uriTest() throws Exception{
		UriComponents uriComponents = 
				UriComponentsBuilder.newInstance()
				//.path("/bbs/read")	// path도 bbs고정이니까 변수 처리 가능
				.path("/{module}/{page}")
				.queryParam("bid", 100)
				.queryParam("numPerPage", 11)
				//.build();
				.build()
				.expand("bbs", "read")	//앞의 변수 2개를 순서대로 넣어주면 됨
				.encode();	//인코딩
				
		logger.info("/bbs/read?bid=100&numPerPage=11");
		logger.info(uriComponents.toString());	//위의 일일히 치는 주소랑 같은지 확인
	}
	
	
	
	
	
	
	
	
	
	
	
}
