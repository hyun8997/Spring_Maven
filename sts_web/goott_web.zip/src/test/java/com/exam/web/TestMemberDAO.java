package com.exam.web;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.exam.dao.MemberDAO;
import com.exam.dto.MemberDTO;

// dao 기능 테스트
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class TestMemberDAO {
	
	@Inject
	private MemberDAO memberDAO;		// interface이고 구현한 객체가 없으므로 이것만 있으면 에러남
	
	@Test
	public void testTime() {
		System.out.println(memberDAO.getTIme());
	}
	
	//@Test
	public void testInsertMember() {			//test 이지만 실제로 db에 값 들어감
		MemberDTO mdto = new MemberDTO();
//		mdto.setUid("hong");
//		mdto.setPwd("1234");
//		mdto.setUsername("gildong");
//		mdto.setEmail("hwal@din.dang");
		
//		mdto.setUid("yu");
//		mdto.setPwd("2345");
//		mdto.setUsername("gwansun");
//		mdto.setEmail("3.1@korea.com");
		
		memberDAO.insertMember(mdto);
	}
	
	
	
}
